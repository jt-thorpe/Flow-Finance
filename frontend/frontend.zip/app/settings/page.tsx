import { Settings } from "../../components/ui/temp_page";

export default Settings;
