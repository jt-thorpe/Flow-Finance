import { Insights } from "../../components/ui/temp_page";

export default Insights;
