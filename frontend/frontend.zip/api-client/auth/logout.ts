import { API_URL } from "../../config/config";



export const logout = async (): Promise<boolean> => {
    try {
        const response = await fetch(`${API_URL}/api/auth/logout`, {
            method: "POST",
            credentials: "include",
        });

        if (!response.ok) {
            console.error("Logout failed:", response.statusText);
            return false;
        }

        return true;
    } catch (error) {
        console.error("Logout error:", error);
        return false;
    }
};
