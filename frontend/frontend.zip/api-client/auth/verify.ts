import type { NextApiRequest, NextApiResponse } from 'next';
import { API_URL } from '../../config/config';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    try {
        const token = req.cookies.jwt; // Read token from HTTP-only cookie

        if (!token) {
            return res.status(401).json({ message: 'Unauthorized' });
        }

        const response = await fetch(`${API_URL}/api/auth/verify`, {
            method: "GET",
            headers: { "Content-Type": "application/json" },
            credentials: 'include',
        });

        if (!response.ok) {
            return res.status(401).json({ message: 'Invalid token' });
        }

        const user = await response.json();
        return res.status(200).json(user);
    } catch (error) {
        return res.status(500).json({ message: 'Internal server error' });
    }
}
