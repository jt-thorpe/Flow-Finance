import { API_URL } from "../../config/config";

export default async function login(email: string, password: string): Promise<boolean> {
    try {
        const response = await fetch(`${API_URL}/api/auth/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password }),
        });

        if (!response.ok) {
            console.error("Login failed:", response.statusText);
            return false;
        }

        return true;
    } catch (error) {
        console.error("Login error:", error);
        return false;
    }
};
