import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';

export function middleware(req: NextRequest) {
    const token = req.cookies.get('jwt')?.value; // Read JWT from cookies

    const protectedRoutes = ['/dashboard', '/profile', '/settings']; // Add protected routes

    if (protectedRoutes.includes(req.nextUrl.pathname)) {
        if (!token) {
            return NextResponse.redirect(new URL('/login', req.url)); // Redirect if no token
        }
    }

    return NextResponse.next();
}

// Apply middleware only to protected routes
export const config = {
    matcher: ['/dashboard', '/profile', '/settings'],
};
