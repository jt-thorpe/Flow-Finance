"use client";

import { createContext, ReactNode, useContext, useEffect, useMemo, useState } from 'react';

interface AuthProviderProps {
    readonly children: ReactNode;
}

interface AuthContextType {
    user: any;
    loading: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: AuthProviderProps) {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetch('/lib/verify')
            .then(res => res.json())
            .then(data => {
                if (data?.message !== 'Unauthorized') {
                    setUser(data);
                }
                setLoading(false);
            })
            .catch(() => setLoading(false));
    }, []);

    // Wrap context value in useMemo to prevent unnecessary re-renders
    const contextValue = useMemo(() => ({ user, loading }), [user, loading]);

    return (
        <AuthContext.Provider value={contextValue}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    return useContext(AuthContext);
}
